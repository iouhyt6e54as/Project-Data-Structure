public class Students {
    int studentID ;
    Students next ;

    Students(int studentID){
        this.studentID = studentID ;
        this.next = null ;
    }
}
