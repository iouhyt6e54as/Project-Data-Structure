public class Courses {
    int courseID ;
    Courses next ;

    Courses(int courseID){
        this.courseID = courseID ;
        this.next = null ;
    }
}
