public class Sstack {
        int studentID ;
        int courseID ;
        String type ;

        public Sstack(int studentID, int courseID , String type) {
            this.studentID = studentID ;
            this.courseID = courseID;
            this.type = type ;
        }

}
